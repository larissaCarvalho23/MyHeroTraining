package com.ifsp.MyHeroTraining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyHeroTrainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
